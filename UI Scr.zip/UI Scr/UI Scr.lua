--Action Bar--
MainMenuBarArtFrame.RightEndCap:Hide(); --Hides right Gryphon
MainMenuBarArtFrame.LeftEndCap:Hide(); --Hides left Gryphon
StatusTrackingBarManager:Hide(); --Hides XP bars
MicroButtonAndBagsBar:Hide(); --Hides Bags
MainMenuBarArtFrameBackground:Hide(); --Hides Backround of a action bar
ActionBarUpButton:Hide(); --Hides Action button up
ActionBarDownButton:Hide(); --Hides Action button down
MainMenuBarArtFrame.PageNumber:Hide(); --Hides action page number
ActionButton1:ClearAllPoints(); --Moves bar to bottom of screen
MultiBarBottomLeftButton1:ClearAllPoints() 
MultiBarBottomLeftButton1:SetPoint("CENTER",-232,-10)  -- Aligns action bar 7-1
MultiBarBottomLeftButton1.SetPoint = function() end
MultiBarBottomRightButton7:ClearAllPoints() 
MultiBarBottomRightButton7:SetPoint("RIGHT",-252,40)  
MultiBarBottomRightButton7.SetPoint = function() end
MultiBarBottomRightButton1:ClearAllPoints() 
MultiBarBottomRightButton1:SetPoint("RIGHT",-252,-1)  
MultiBarBottomRightButton1.SetPoint = function() end

--UI--
FocusFrame:SetScale(1.1);
FocusFrameSpellBar:SetScale(1.45);
TargetFrameSpellBar:SetScale(1.40);